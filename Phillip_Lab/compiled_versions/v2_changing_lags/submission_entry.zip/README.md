# HGB upgrade experiment
Python 3.11+; install pinned requirements before offline run. Run python -m lag_model.run predict --model-dir . --data /data --out /output/submission.csv.
Model selection uses tuning episodes. Includes champion fallback and features comparing recent versus older per-machine lag relationships. See report.json.
