"""Cross-fitted probability calibration."""
