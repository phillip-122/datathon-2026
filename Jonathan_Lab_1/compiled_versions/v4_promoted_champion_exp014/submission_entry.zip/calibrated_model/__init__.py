"""Cross-fitted probability calibration."""
