# Cross-fitted probability calibration
Python 3.11+. Prepare pinned requirements before offline prediction. Run python -m calibrated_model.run predict --model-dir . --data /data --out /output/submission.csv.
Base model is frozen in base-entry. A six-parameter regularized temperature/bias map is fitted to released tuning true probabilities only, after penalty selection via episode cross-fitting. No test labels. Audit has been inspected previously. See report.json, including bootstrap uncertainty.
